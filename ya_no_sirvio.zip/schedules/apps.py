from django.apps import AppConfig


class SchedulesConfig(AppConfig):
    name = 'schedules'
