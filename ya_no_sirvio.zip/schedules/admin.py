from django.contrib import admin
from .models import Career, Subject
# Register your models here.

admin.site.register(Career)
admin.site.register( Subject)
